If this dataset is helpful to you, please cite the following:



Zhou W, He J, Li Y, Sun Z, Chen J, Wang L, Hui H, Chen X. Multi-focus image fusion with enhancement filtering for robust vascular quantification using photoacoustic microscopy. Opt Lett. 2022 Aug 1;47(15):3732-3735. doi: 10.1364/OL.459629. 